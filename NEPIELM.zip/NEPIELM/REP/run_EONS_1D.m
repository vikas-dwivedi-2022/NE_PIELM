clc; clear all; close all;
Nf=500;
Ns=100:50:800;
for i=1:length(Ns)
    err(i)= EONS_1D(Nf,Ns(i));
    clc;
end    

f1 = figure(1);
W = 6; H = 4;
plot(Ns,err,'--ko','Linewidth',2);
set(f1,'PaperUnits','inches');set(f1,'PaperOrientation','portrait');
set(f1,'PaperSize',[H,W])    ;set(f1,'PaperPosition',[0,0,W,H]);
xlabel('Number of neurons');
ylabel('log(max(err)) ');
%title(strcat('t=',num2str(X_lft(k,2))));
%legend('NE-PIELM','Exact','Location','best')
% axis([Xmin,Xmax,-0.1,1.1])
print(f1,'-depsc','NIPIELM_sharp_fails.eps');
