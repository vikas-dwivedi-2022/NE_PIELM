clc;clear all; close all;
%----------------%
% function       %
%----------------%
Nf=10; % Input Data
x=linspace(-1,1,Nf);
y=@(x)exp(-sin(pi*x)).*cos(2*pi*x)+x.^2;
%----------------%
% Architecture   %
%----------------%
Ns=Nf;  % No of Neurons
m=rand(Ns,1);
b=rand(Ns,1);

%----------------%
% Lc=beta        %
%----------------%
L=zeros(Ns,Ns);
beta=zeros(Ns,1);

% dumb implementation
tic;
for i=1:Ns
    for j= 1:Ns
        for k=1:Nf
            L(i,j)=L(i,j)+phi(m(j)*x(k)+b(j))*phi(m(i)*x(k)+b(i));
        end
    end
end  
toc;
disp('L dumb'); disp(L);

% sensible implementation
L=zeros(Ns,Ns);
tic;
% step 1: calculate only symmetric part
for i=1:Ns
    vi= phi(m(i)*x+b(i));
    for j= i:Ns
        vj = phi(m(j)*x+b(j));
        L(i,j)=vi*vj';           
    end
end

for i=1:Ns
    for j =1:i
        L(i,j)=L(j,i);
    end
end
toc;

disp('L sensible'); disp(L);
