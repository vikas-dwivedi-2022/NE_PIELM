function err_ord = EONS_dist_1D(NBx)
nbx=10; 
ns= nbx;
xL=0;xR=1;
y=@(x)tanh(100*(x-0.5));

%----------------%
% GLOBAL PARAMS  %
%----------------%

LHS_G  = cell(NBx,NBx);
RHS_G  = cell(NBx,1);

X_G  = cell(NBx,1);
M_G  = cell(NBx,1);
B_G  = cell(NBx,1);

Y_HAT= cell(NBx,1);
%----------------%
% LOCAL PARAMS   %
%----------------%
dX=(xR-xL)/NBx;
for i = 1:NBx
    RHS_G{i,1}=zeros(ns,1);
    X_G{i,1}=linspace(xL+(i-1)*dX,xL+i*dX,nbx)';
    M_G{i,1}=rand(ns,1);
    B_G{i,1}=rand(ns,1);
    for j= 1:NBx
        LHS_G{i,j}=zeros(ns,ns);
    end
end

%-----------------------------%
% ASSEMBLY OF LOCAL MATRICES  %
%-----------------------------%

for p = 1:NBx
    beta=zeros(ns,1);  
    for i=1:ns
        for k=1:nbx
            beta(i)=beta(i)+(1/nbx)*y(X_G{p,1}(k))...
                           *phi(M_G{p,1}(i)*X_G{p,1}(k)+B_G{p,1}(i));
        end  
    end
    RHS_G{p,1}=beta;
end
  
for p = 1:NBx
    L=zeros(ns,ns);
    for i=1:ns
        for j= 1:ns
            for k=1:nbx
                L(i,j)=L(i,j)+(1/nbx)*phi(M_G{p,1}(j)*X_G{p,1}(k)+B_G{p,1}(j))...
                             *phi(M_G{p,1}(i)*X_G{p,1}(k)+B_G{p,1}(i));
            end
        end
    end   
    LHS_G{p,p}=L; 
end  
%-----------------------------%
% ADDITIONAL INTERFACE TERMS  %
%-----------------------------%
for p = 1:NBx-1
    A11=zeros(ns,ns);A12=zeros(ns,ns);
    A21=zeros(ns,ns);A22=zeros(ns,ns);
    
    for i =1:ns
        for j=1:ns
            A11(i,j)= phi(M_G{p,1}(i)  *X_G{p,1}(nbx) + B_G{p,1}(i))*...
                      phi(M_G{p,1}(j)  *X_G{p,1}(nbx) + B_G{p,1}(j));
                      
            A12(i,j)=-phi(M_G{p,1}(i)  *X_G{p,1}(nbx) + B_G{p,1}(i))*...
                      phi(M_G{p+1,1}(j)*X_G{p+1,1}(1) + B_G{p+1,1}(j)); 
                      
            A21(i,j)=-phi(M_G{p+1,1}(i)*X_G{p+1,1}(1) + B_G{p+1,1}(i))*...
                      phi(M_G{p,1}(j)  *X_G{p,1}(nbx) + B_G{p,1}(j));
                      
            A22(i,j)= phi(M_G{p+1,1}(i)*X_G{p+1,1}(1) + B_G{p+1,1}(i))*...
                      phi(M_G{p+1,1}(j)*X_G{p+1,1}(1) + B_G{p+1,1}(j));
        end
    end
    
    % LEFT
    LHS_G{p,p}  =LHS_G{p,p}   + A11; LHS_G{p,p+1}   = LHS_G{p,p+1}   + A12; 
    % RIGHT
    LHS_G{p+1,p}=LHS_G{p+1,p} + A21; LHS_G{p+1,p+1} = LHS_G{p+1,p+1} + A22;
end

%----------------------%
%    PREDICTION        %
%----------------------%
LHS_G = cell2mat(LHS_G);
RHS_G = cell2mat(RHS_G);

tic;
C=LHS_G\RHS_G;
toc;
for p=1:NBx
    yhat=zeros(nbx,1);
    ind=1+(p-1)*ns:p*ns;
    for i=1:nbx        
        yhat(i)=phi(M_G{p,1}*X_G{p,1}(i)+B_G{p,1})'*C(ind);
    end
    Y_HAT{p,1}=yhat;
end

Y_PRED = cell2mat(Y_HAT);
Y_TRUE = y(cell2mat(X_G));

%plot(cell2mat(X_G),Y_PRED,'-r'); hold on;
%plot(cell2mat(X_G),Y_TRUE,'ko');

max_err=max(abs(Y_PRED-Y_TRUE));
err_ord=log10(max_err);
end
