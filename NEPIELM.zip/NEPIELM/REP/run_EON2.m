clc; clear all; close all;

NBx=10:5:60;
for i=1:length(NBx)
    err(i)= EONS_dist_1D(NBx(i));
    clc;
end    

f1 = figure(1);
W = 6; H = 4;
plot(NBx,err,'--ko','Linewidth',2);
set(f1,'PaperUnits','inches');set(f1,'PaperOrientation','portrait');
set(f1,'PaperSize',[H,W])    ;set(f1,'PaperPosition',[0,0,W,H]);
xlabel('Number of local NE-PIELMs');
ylabel('log(max(err)) ');
%title(strcat('t=',num2str(X_lft(k,2))));
%legend('NE-PIELM','Exact','Location','best')
% axis([Xmin,Xmax,-0.1,1.1])
print(f1,'-depsc','EON2.eps');
