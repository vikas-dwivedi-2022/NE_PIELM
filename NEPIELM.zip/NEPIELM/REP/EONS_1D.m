function err_ord = EONS_1D(Nf,Ns)
x=linspace(0,1,Nf);
%y=@(x)sin(2*pi*x);
y=@(x)tanh(100*(x-0.5));
%----------------%
% Architecture   %
%----------------%
m=rand(Ns,1);
b=rand(Ns,1);

%----------------%
% Lc=beta        %
%----------------%
L=zeros(Ns,Ns);
beta=zeros(Ns,1);

for i=1:Ns
    vi= phi(m(i)*x+b(i));
    for j= i:Ns
        vj = phi(m(j)*x+b(j));
        L(i,j)=vi*vj';           
    end
end

for i=1:Ns
    for j =1:i
        L(i,j)=L(j,i);
    end
end  

for i=1:Ns
    for k=1:Nf
        beta(i)=beta(i)+y(x(k))*phi(m(i)*x(k)+b(i));
    end  
end
c=L\beta;
%----------------%
% Prediction     %
%----------------%

for i=1:Nf
    yhat(i)=phi(m*x(i)+b)'*c;
end

max_err=max(abs(y(x)-yhat));
err_ord = log10(max_err);
end