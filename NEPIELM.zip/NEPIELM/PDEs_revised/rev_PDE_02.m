clc;close all; clear all;
ax=1;ay=0.5;
exact=@(x,y) 0.5*cos(pi*x).*sin(pi*y);
R=@(x,y) 0.5*pi*(0.5*(cos(pi*x).*cos(pi*y))-(sin(pi*x).*sin(pi*y)));

%exact=@(x,y)0.25*(1-x.^2-y.^2);
%R=@(x,y) -1+0*x+0*y;

%---------------%
% QUERY POINTS  %
%---------------%
[pde_pts,bc_pts]=disk_data(0,0,1,250);

N_pde =length(pde_pts);
N_bc  =length(bc_pts);

f1=figure(1)
W = 4; H = 4;
scatter(pde_pts(:,1),pde_pts(:,2),'k','^'); hold on;
scatter(bc_pts(:,1),bc_pts(:,2),'r','s');hold off;
set(f1,'PaperUnits','inches');set(f1,'PaperOrientation','portrait');
set(f1,'PaperSize',[H,W])    ;set(f1,'PaperPosition',[0,0,W,H]);
xlabel('x');ylabel('y');
print(f1,'-depsc','steady_adv_train.eps');

%----------------%
% Architecture   %
%----------------%
Ns=N_pde+N_bc;  % No of Neurons

m=rand(Ns,1);
n=rand(Ns,1);
b=rand(Ns,1);

%----------------%
% Lc=beta        %
%----------------%
L=zeros(Ns,Ns);
beta=zeros(Ns,1);


Lpde=zeros(Ns,Ns);
Lbc=zeros(Ns,Ns);
%--------------%
% L(due to PDE)%
%--------------%

%for i=1:Ns
%    for j= 1:Ns
%        for k=1:N_pde
%            L(i,j)=L(i,j)+(1/N_pde)*(ax*m(j)+ay*n(j))*dphi(m(j)*pde_pts(k,1)+n(j)*pde_pts(k,2)+b(j))*...
%                                    (ax*m(i)+ay*n(i))*dphi(m(i)*pde_pts(k,1)+n(i)*pde_pts(k,2)+b(i));
%                                   
%        end
%    end
%end  

for i=1:Ns
    vi= (ax*m(i)+ay*n(i))*dphi(m(i)*pde_pts(:,1)'+n(i)*pde_pts(:,2)'+b(i));
    for j= i:Ns
        vj = (ax*m(j)+ay*n(j))*dphi(m(j)*pde_pts(:,1)'+n(j)*pde_pts(:,2)'+b(j));
        Lpde(i,j)=vi*vj';           
    end
end



for i=1:Ns
    for j =1:i
        Lpde(i,j)=Lpde(j,i);
    end
end  

Lpde=(1/N_pde)*Lpde;
%--------------%
% L(due to BC) %
%--------------%

%for i=1:Ns
%    for j= 1:Ns
%        for k=1:N_bc
%            L(i,j)=L(i,j)+(1/N_bc)*phi(m(j)*bc_pts(k,1)+n(j)*bc_pts(k,2)+b(j))...
%                                  *phi(m(i)*bc_pts(k,1)+n(i)*bc_pts(k,2)+b(i));
%        end
%    end
%end          
for i=1:Ns
    vi=phi(m(i)*bc_pts(:,1)'+n(i)*bc_pts(:,2)'+b(i));
    for j= 1:Ns
        vj=phi(m(j)*bc_pts(:,1)'+n(j)*bc_pts(:,2)'+b(j));
        Lbc(i,j)=vi*vj';
    end
end          

Lbc=(1/N_bc)*Lbc;
L=Lpde+Lbc;
%-----------------%
% beta(due to PDE)%
%-----------------%
for i=1:Ns    
    for k=1:N_pde
        beta(i)=beta(i)+(1/N_pde)*R(pde_pts(k,1),pde_pts(k,2))*...
        (ax*m(i)+ay*n(i))*dphi(m(i)*pde_pts(k,1)+n(i)*pde_pts(k,2)+b(i));
    end  
end

%-----------------%
% beta(due to BC) %
%-----------------%
for i=1:Ns    
    for k=1:N_bc
        beta(i)=beta(i)+(1/N_bc)*exact(bc_pts(k,1),bc_pts(k,2))*phi(m(i)*bc_pts(k,1)+n(i)*bc_pts(k,2)+b(i));
    end  
end


%----------------%
% Prediction     %
%----------------%

for k=1:N_pde
    yhat(k)=tanh(m*pde_pts(k,1)+n*pde_pts(k,2)+b)'*c;
    ytrue(k)=exact(pde_pts(k,1),pde_pts(k,2));
end

disp('Max Error = '); disp(max(abs(yhat-ytrue)));


f1=figure(2)
W = 4; H = 4;
tri = delaunay(pde_pts(:,1),pde_pts(:,2));
h = trisurf(tri, pde_pts(:,1),pde_pts(:,2), yhat-ytrue);
axis vis3d
axis off
view(0,90)
shading interp;
colorbar 
set(f1,'PaperUnits','inches');set(f1,'PaperOrientation','portrait');
set(f1,'PaperSize',[H,W])    ;set(f1,'PaperPosition',[0,0,W,H]);
xlabel('x');ylabel('y');
print(f1,'-depsc','steady_adv_error.eps');
