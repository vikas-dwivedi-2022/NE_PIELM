function [X_pde, X_bc]=train_map_data
filename='australia_train.csv';
M=csvread(filename);
X=M(:,2);Y=M(:,1);
% collocation pts
X_pde=[X,Y];

% boundary points
worldmap({'World'});
land = shaperead('landareas.shp', 'UseGeoCoords', true);
lat=land(5).Lat;lon=land(5).Lon;
lat=lat(1:end-1);lon=lon(1:end-1);
lat=rescale(lat);lon=rescale(lon);
lat=lat';lon=lon';
%------------------------------------%
% boundary points
X_bc=[lat, lon];
X_pde=[X_pde;X_bc];
end