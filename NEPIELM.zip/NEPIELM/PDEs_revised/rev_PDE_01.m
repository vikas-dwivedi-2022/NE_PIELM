%----------------------------%
% RUN THIS ONE FOR ADVECTION %
%----------------------------%
clc;close all; clear all;
init=@(x)sin(2*pi*x);
xL=0;xR=1;
yL=0;yR=0.2;
%---------------%
% QUERY POINTS  %
%---------------%

%-----%
% IC  %
%-----%
N_ic=49;
x_ic=linspace(xL,xR,N_ic);
y_ic=0*x_ic;
ic_pts=[x_ic' y_ic'];

%-----%
% BC  %
%-----%
N_bc=49;
y_bc=linspace(yL,yR,N_bc);
x_lbc=xL*ones(size(y_bc));
x_rbc=xR*ones(size(y_bc));

bc_pts=[x_lbc' y_bc';
        x_rbc' y_bc'];
        
%-----%
% PDE %
%-----% 
N_pde= 249;
x_pde = (xR-xL).*rand(N_pde,1) + xL;
y_pde = (yR-yL).*rand(N_pde,1) + yL;
pde_pts=[x_pde y_pde];

%----------------%
% Architecture   %
%----------------%
Ns=N_pde+N_bc+N_ic;  % No of Neurons

m=rand(Ns,1);
n=rand(Ns,1);
b=rand(Ns,1);

%----------------%
% Lc=beta        %
%----------------%
L=zeros(Ns,Ns);
beta=zeros(Ns,1);


Lpde=zeros(Ns,Ns);
Lic=zeros(Ns,Ns);
Lbc=zeros(Ns,Ns);
%--------------%
% due to PDE   %
%--------------%
for i=1:Ns
    vi= (m(i)+n(i))*dphi(m(i)*pde_pts(:,1)'+n(i)*pde_pts(:,2)'+b(i));
    for j= i:Ns
        vj= (m(j)+n(j))*dphi(m(j)*pde_pts(:,1)'+n(j)*pde_pts(:,2)'+b(j));
        Lpde(i,j)=vi*vj';
%        for k=1:N_pde
%            L(i,j)=L(i,j)+(1/N_pde)*(m(j)+n(j))*dphi(m(j)*pde_pts(k,1)+n(j)*pde_pts(k,2)+b(j))...
%                                   *(m(i)+n(i))*dphi(m(i)*pde_pts(k,1)+n(i)*pde_pts(k,2)+b(i));
%        end
    end
end 
for i=1:Ns
    for j =1:i
        Lpde(i,j)=Lpde(j,i);
    end
end  

Lpde=(1/N_pde)*Lpde; 

%--------------%
% due to IC    %
%--------------%

for i=1:Ns
    vi= phi(m(i)*ic_pts(:,1)'+n(i)*ic_pts(:,2)'+b(i));
    for j= i:Ns
        vj= phi(m(j)*ic_pts(:,1)'+n(j)*ic_pts(:,2)'+b(j));
        Lic(i,j)=vi*vj';
        %for k=1:N_ic
        %    L(i,j)=L(i,j)+(1/N_ic)*phi(m(j)*ic_pts(k,1)+n(j)*ic_pts(k,2)+b(j))...
        %                          *phi(m(i)*ic_pts(k,1)+n(i)*ic_pts(k,2)+b(i));
        %end
    end
end          
for i=1:Ns
    for j =1:i
        Lic(i,j)=Lic(j,i);
    end
end  

Lic=(1/N_ic)*Lic; 

%--------------%
% due to BC    %
%--------------%

for i=1:Ns
    for j= 1:Ns
        for k=1:N_bc
            Lbc(i,j)=Lbc(i,j)+(1/N_bc)*(phi(m(j)*bc_pts(k,1)+n(j)*bc_pts(k,2)+b(j))-...
                                    phi(m(j)*bc_pts(k+N_bc,1)+n(j)*bc_pts(k+N_bc,2)+b(j)))...                                            )
                                  *(phi(m(i)*bc_pts(k,1)+n(i)*bc_pts(k,2)+b(i))-...
                                    phi(m(i)*bc_pts(k+N_bc,1)+n(i)*bc_pts(k+N_bc,2)+b(i)));
        end
    end
end
L=Lpde+Lbc+Lic;
%--------------%
% due to IC    %
%--------------%
tic;
for i=1:Ns    
    for k=1:N_ic
        beta(i)=beta(i)+(1/N_ic)*init(ic_pts(k,1))*phi(m(i)*ic_pts(k,1)+n(i)*ic_pts(k,2)+b(i));
    end  
end
toc;
tic;c=L\beta;toc;

f1 = figure(1);
W = 4; H = 4;
scatter(pde_pts(:,1),pde_pts(:,2),'k','^');hold on;
scatter(bc_pts(:,1),bc_pts(:,2),'r','s');hold on;
scatter(ic_pts(:,1),ic_pts(:,2),'b');hold off;
set(f1,'PaperUnits','inches');set(f1,'PaperOrientation','portrait');
set(f1,'PaperSize',[H,W])    ;set(f1,'PaperPosition',[0,0,W,H]);
%xlabel('$$ x $$','Interpreter','latex');
%ylabel('$$ t $$','Interpreter','latex');
xlabel('x');ylabel('t');
%title(strcat('t=',num2str(X_lft(k,2))));
%legend('NE-PIELM','Exact','Location','best')
%axis(xL,xR,yL,yR)
print(f1,'-depsc','adv_train.eps');
%----------------%
% Prediction     %
%----------------%
N_pred=N_ic*N_bc; dy=y_bc(2)-y_bc(1);
[x_pred,y_pred]=meshgrid(x_ic,y_bc);  

x_pred=x_pred';  
y_pred=y_pred';

figure(2)
ind_=[1, 25, 49]
for i =1:3
    t = ind_(i);
    for s = 1:N_ic
       yhat(s,t)=tanh(m*x_pred(s,t)+n*y_pred(s,t)+b)'*c;

    end       
f1 = figure(2);
W = 8; H = 4;
subplot(1,3,i)
    plot(x_ic,yhat(:,t)','-r','Linewidth',3); hold on;
    plot(x_ic,init(x_ic-(t-1)*dy),'--b','Linewidth',3); hold off;
set(f1,'PaperUnits','inches');set(f1,'PaperOrientation','portrait');
set(f1,'PaperSize',[H,W])    ;set(f1,'PaperPosition',[0,0,W,H]);
xlabel('x');ylabel('u');
title(strcat('t=',num2str((i-1)*0.1)));
axis([0 1 -1.2 1.2]);
%legend('NE-PIELM','Exact','Location','northwest')
% axis([Xmin,Xmax,-0.1,1.1])
print(f1,'-depsc','t.eps');
    
end

    
