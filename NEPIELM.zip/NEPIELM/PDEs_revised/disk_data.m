function [X_pde, X_bc]=disk_data(xc,yc,rc,N)
X=zeros(N,2); theta=linspace(0,2*pi,50);
for i=1:N
a=2*pi*rand; r=sqrt(rand);
X(i,1)=(rc*r)*cos(a)+xc;X(i,2)=(rc*r)*sin(a)+yc;
end
xq=X(:,1);yq=X(:,2);

xv=xc+rc*cos(theta);
yv=xc+rc*sin(theta);

[in] = inpolygon(xq,yq,xv,yv);

X_pde=[xq(in) yq(in)];
X_bc=[xv'  yv'];
X_pde=[X_pde;X_bc];
end
