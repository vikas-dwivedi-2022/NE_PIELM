clc;close all; clear all;
init=@(x)exp(-50*(x-0.4).^2);
xL=0;xR=1;
yL=0;yR=0.5;
%---------------%
% QUERY POINTS  %
%---------------%
%-----%
% IC  %
%-----%
N_ic=49;
x_ic=linspace(xL,xR,N_ic);
y_ic=0*x_ic;
ic_pts=[x_ic' y_ic'];

%-----%
% BC  %
%-----%
N_bc=49;
y_bc=linspace(yL,yR,N_bc);
x_lbc=xL*ones(size(y_bc));
x_rbc=xR*ones(size(y_bc));

bc_pts=[x_lbc' y_bc';
        x_rbc' y_bc'];
        
%-----%
% PDE %
%-----% 
N_pde= 499;
x_pde = (xR-xL).*rand(N_pde,1) + xL;
y_pde = (yR-yL).*rand(N_pde,1) + yL;
pde_pts=[x_pde y_pde];

f1 = figure(1);
W = 4; H = 4;
scatter(pde_pts(:,1),pde_pts(:,2),'k','^');hold on;
scatter(bc_pts(:,1),bc_pts(:,2),'r','s');hold on;
scatter(ic_pts(:,1),ic_pts(:,2),'b');hold off;
set(f1,'PaperUnits','inches');set(f1,'PaperOrientation','portrait');
set(f1,'PaperSize',[H,W])    ;set(f1,'PaperPosition',[0,0,W,H]);
xlabel('$$ x $$','Interpreter','latex');
ylabel('$$ y $$','Interpreter','latex');
%title(strcat('t=',num2str(X_lft(k,2))));
%legend('NE-PIELM','Exact','Location','best')
axis([xL,xR,yL,yR])
print(f1,'-depsc','adv_train.eps');

