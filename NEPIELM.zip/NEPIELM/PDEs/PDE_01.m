clc;close all; clear all;
init=@(x)sin(2*pi*x);
xL=0;xR=1;
yL=0;yR=0.1;
%---------------%
% QUERY POINTS  %
%---------------%

%-----%
% IC  %
%-----%
N_ic=25;
x_ic=linspace(xL,xR,N_ic);
y_ic=0*x_ic;
ic_pts=[x_ic' y_ic'];

%-----%
% BC  %
%-----%
N_bc=5;
y_bc=linspace(yL,yR,N_bc);
x_lbc=xL*ones(size(y_bc));
x_rbc=xR*ones(size(y_bc));

bc_pts=[x_lbc' y_bc';
        x_rbc' y_bc'];
        
%-----%
% PDE %
%-----% 
N_pde=N_ic*N_bc; 
[x_pde,y_pde]=meshgrid(x_ic,y_bc);  
x_pde=reshape(x_pde,N_pde,1);  
y_pde=reshape(y_pde,N_pde,1); 

pde_pts=[x_pde y_pde];

%----------------%
% Architecture   %
%----------------%
Ns=N_pde+N_bc+N_ic;  % No of Neurons

m=rand(Ns,1);
n=rand(Ns,1);
b=rand(Ns,1);

%----------------%
% Lc=beta        %
%----------------%
L=zeros(Ns,Ns);
beta=zeros(Ns,1);

%--------------%
% due to PDE   %
%--------------%

for i=1:Ns
    for j= 1:Ns
        for k=1:N_pde
            L(i,j)=L(i,j)+(1/N_pde)*(m(j)+n(j))*dphi(m(j)*pde_pts(k,1)+n(j)*pde_pts(k,2)+b(j))...
                                   *(m(i)+n(i))*dphi(m(i)*pde_pts(k,1)+n(i)*pde_pts(k,2)+b(i));
        end
    end
end  

%--------------%
% due to IC    %
%--------------%

for i=1:Ns
    for j= 1:Ns
        for k=1:N_ic
            L(i,j)=L(i,j)+(1/N_ic)*phi(m(j)*ic_pts(k,1)+n(j)*ic_pts(k,2)+b(j))...
                                  *phi(m(i)*ic_pts(k,1)+n(i)*ic_pts(k,2)+b(i));
        end
    end
end          


%--------------%
% due to BC    %
%--------------%
for i=1:Ns
    for j= 1:Ns
        for k=1:N_bc
            L(i,j)=L(i,j)+(1/N_bc)*(phi(m(j)*bc_pts(k,1)+n(j)*bc_pts(k,2)+b(j))-...
                                    phi(m(j)*bc_pts(k+N_bc,1)+n(j)*bc_pts(k+N_bc,2)+b(j)))...                                            )
                                  *(phi(m(i)*bc_pts(k,1)+n(i)*bc_pts(k,2)+b(i))-...
                                    phi(m(i)*bc_pts(k+N_bc,1)+n(i)*bc_pts(k+N_bc,2)+b(i)));
        end
    end
end
%--------------%
% due to IC    %
%--------------%
for i=1:Ns    
    for k=1:N_ic
        beta(i)=beta(i)+(1/N_ic)*init(ic_pts(k,1))*phi(m(i)*ic_pts(k,1)+n(i)*ic_pts(k,2)+b(i));
    end  
end

c=L\beta;
%----------------%
% Prediction     %
%----------------%

for k=1:N_pde
    yhat(k)=tanh(m*pde_pts(k,1)+n*pde_pts(k,2)+b)'*c;
end

contourf(reshape(yhat,N_bc,N_ic));