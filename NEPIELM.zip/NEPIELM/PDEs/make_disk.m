function [X_pde, X_bc]=make_disk
N_steps=50;
X=0;Y=0;
range_rho = randi([5 10], 1,N_steps);% no of points in a (given=?)radius
range_theta = 2*pi*randi([0 1], 1,N_steps);
% collocation points
for i= 1:N_steps
    RHO= rand(1,1)*ones(1,range_rho(i));% ?=rand;
    THETA = range_theta(i)*rand(1,range_rho(i));
    x=RHO.*cos(THETA);X=[X;x'];
    y=RHO.*sin(THETA);Y=[Y;y'];
end
% boundary points
rad=1;
theta=linspace(0,2*pi,90);
x=rad.*cos(theta);y=rad.*sin(theta);
%X_bc=[x' y' ones(size(x'))];
X_bc=[x' y'];
X=[X;x'];Y=[Y;y'];
%X_pde=[X Y ones(size(X))];
X_pde=[X Y];
end