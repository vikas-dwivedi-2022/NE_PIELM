clc;clear all; close all;
%----------------%
% USER INPUTS    %
%----------------%
NBx = 17; nbx=10; 
ns= nbx;
xL=0;xR=1;
y=@(x)1+sin(2*pi*x).*cos(4*pi*x);
R=@(x)2*pi*(cos(2*pi*x).*cos(4*pi*x)-2*sin(2*pi*x).*sin(4*pi*x));
BL=y(xL);
%----------------%
% GLOBAL PARAMS  %
%----------------%

LHS_G  = cell(NBx,NBx);
RHS_G  = cell(NBx,1);

X_G  = cell(NBx,1);
M_G  = cell(NBx,1);
B_G  = cell(NBx,1);

Y_HAT= cell(NBx,1);
%----------------%
% LOCAL PARAMS   %
%----------------%
dX=(xR-xL)/NBx;
for i = 1:NBx
    RHS_G{i,1}=zeros(ns,1);
    X_G{i,1}=linspace(xL+(i-1)*dX,xL+i*dX,nbx)';
    M_G{i,1}=rand(ns,1);
    B_G{i,1}=rand(ns,1);
    for j= 1:NBx
        LHS_G{i,j}=zeros(ns,ns);
    end
end

%-----------------------------%
% ASSEMBLY OF LOCAL MATRICES  %
%-----------------------------%

% RHS TERMS
% 1. WITH BC                   
for p = 1:1
    beta=zeros(ns,1);  
    for i=1:ns
        beta(i)=BL*phi(M_G{p,1}(i)*X_G{p,1}(1)+B_G{p,1}(i));                    % due to BC
        for k=1:nbx
            beta(i)=beta(i)+(1/nbx)*R(X_G{p,1}(k))*...
                    M_G{p,1}(i)*dphi(M_G{p,1}(i)*X_G{p,1}(k)+B_G{p,1}(i));      % due to R         
        end  
    end
    RHS_G{p,1}=beta;
end

% 2. WITHOUT BC
for p = 2:NBx
    beta=zeros(ns,1);  
    for i=1:ns
        for k=1:nbx
            beta(i)=beta(i)+(1/nbx)*R(X_G{p,1}(k))*...                          % due to R
                    M_G{p,1}(i)*dphi(M_G{p,1}(i)*X_G{p,1}(k)+B_G{p,1}(i));               
        end  
    end
    RHS_G{p,1}=beta;
end

% LHS TERMS
% 1. WITH BC
for p = 1:1
    L=zeros(ns,ns);
    for i=1:ns
        for j= 1:ns
            L(i,j) = phi(M_G{p,1}(j)*X_G{p,1}(1)+B_G{p,1}(j))*...
                     phi(M_G{p,1}(i)*X_G{p,1}(1)+B_G{p,1}(i));
            for k=1:nbx
                L(i,j)=L(i,j)+(1/nbx)*M_G{p,1}(j)*M_G{p,1}(i)*...
                              dphi(M_G{p,1}(j)*X_G{p,1}(k)+B_G{p,1}(j))*...
                              dphi(M_G{p,1}(i)*X_G{p,1}(k)+B_G{p,1}(i));
            end
        end
    end   
    LHS_G{p,p}=L; 
end  
% 2. WITHOUT BC
for p = 2:NBx
    L=zeros(ns,ns);
    for i=1:ns
        for j= 1:ns
            for k=1:nbx
                L(i,j)=L(i,j)+(1/nbx)*M_G{p,1}(j)*M_G{p,1}(i)*...
                              dphi(M_G{p,1}(j)*X_G{p,1}(k)+B_G{p,1}(j))*...
                              dphi(M_G{p,1}(i)*X_G{p,1}(k)+B_G{p,1}(i));
            end
        end
    end   
    LHS_G{p,p}=L; 
end  
%-----------------------------%
% ADDITIONAL INTERFACE TERMS  %
%-----------------------------%
for p = 1:NBx-1
    A11=zeros(ns,ns);A12=zeros(ns,ns);
    A21=zeros(ns,ns);A22=zeros(ns,ns);
    
    for i =1:ns
        for j=1:ns
            A11(i,j)= phi(M_G{p,1}(i)  *X_G{p,1}(nbx) + B_G{p,1}(i))*...
                      phi(M_G{p,1}(j)  *X_G{p,1}(nbx) + B_G{p,1}(j));
                      
            A12(i,j)=-phi(M_G{p,1}(i)  *X_G{p,1}(nbx) + B_G{p,1}(i))*...
                      phi(M_G{p+1,1}(j)*X_G{p+1,1}(1) + B_G{p+1,1}(j)); 
                      
            A21(i,j)=-phi(M_G{p+1,1}(i)*X_G{p+1,1}(1) + B_G{p+1,1}(i))*...
                      phi(M_G{p,1}(j)  *X_G{p,1}(nbx) + B_G{p,1}(j));
                      
            A22(i,j)= phi(M_G{p+1,1}(i)*X_G{p+1,1}(1) + B_G{p+1,1}(i))*...
                      phi(M_G{p+1,1}(j)*X_G{p+1,1}(1) + B_G{p+1,1}(j));
        end
    end
    
    % LEFT
    LHS_G{p,p}  =LHS_G{p,p}   + A11; LHS_G{p,p+1}   = LHS_G{p,p+1}   + A12; 
    % RIGHT
    LHS_G{p+1,p}=LHS_G{p+1,p} + A21; LHS_G{p+1,p+1} = LHS_G{p+1,p+1} + A22;
end

%----------------------%
%    PREDICTION        %
%----------------------%
LHS_G = cell2mat(LHS_G);
RHS_G = cell2mat(RHS_G);

tic;
C=LHS_G\RHS_G;
toc;
for p=1:NBx
    yhat=zeros(nbx,1);
    ind=1+(p-1)*ns:p*ns;
    for i=1:nbx        
        yhat(i)=phi(M_G{p,1}*X_G{p,1}(i)+B_G{p,1})'*C(ind);
    end
    Y_HAT{p,1}=yhat;
end

Y_PRED = cell2mat(Y_HAT);
Y_TRUE = y(cell2mat(X_G));

plot(cell2mat(X_G),Y_PRED,'-r'); hold on;
plot(cell2mat(X_G),Y_TRUE,'ko');

disp('Max Error = ');disp(max(abs(Y_PRED-Y_TRUE)));