function y=dphi(x)
         y=sech(x).^2;
end  