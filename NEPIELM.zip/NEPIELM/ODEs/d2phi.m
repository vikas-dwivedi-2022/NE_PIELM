function y=d2phi(x)
         y=-2*(sech(x).^2).*(tanh(x));
end  