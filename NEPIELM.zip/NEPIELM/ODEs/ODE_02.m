clc;clear all; close all;
%----------------%
% function       %
%----------------%
Nf=30; % Input Data
x=linspace(0,1,Nf);
y=@(x)sin(pi*x);
R=@(x)-pi^2*y(x);
BL=y(x(1));
BR=y(x(end));
%----------------%
% Architecture   %
%----------------%
Ns=Nf;  % No of Neurons
m=rand(Ns,1);
b=rand(Ns,1);

%----------------%
% Lc=beta        %
%----------------%
L=zeros(Ns,Ns);
beta=zeros(Ns,1);

for i=1:Ns
    for j= 1:Ns
        L(i,j) = phi(m(j)*x(1)+b(j))*phi(m(i)*x(1)+b(i))+phi(m(j)*x(Nf)+b(j))*phi(m(i)*x(Nf)+b(i));
        for k=2:Nf-1
            L(i,j)=L(i,j)+(1/(Nf-2))*m(j)^2*m(i)^2*d2phi(m(j)*x(k)+b(j))*d2phi(m(i)*x(k)+b(i));
        end
    end
end  

for i=1:Ns
    beta(i)=BL*phi(m(i)*x(1)+b(i))+BR*phi(m(i)*x(Nf)+b(i));
    for k=2:Nf-1
        beta(i)=beta(i)+(1/(Nf-2))*R(x(k))*m(i)^2*d2phi(m(i)*x(k)+b(i));
    end  
end
c=L\beta;
%----------------%
% Prediction     %
%----------------%

for i=1:Nf
    yhat(i)=tanh(m*x(i)+b)'*c;
end

disp('Max Error ='); disp(max(abs(y(x)-yhat)));

disp('Max Error ='); disp(max(abs(y(x)-yhat)));

f1 = figure(1);
W = 4; H = 4;
plot(x,yhat,'-r','Linewidth',3);hold on;
plot(x,y(x),'--b','Linewidth',3);hold off; 
set(f1,'PaperUnits','inches');set(f1,'PaperOrientation','portrait');
set(f1,'PaperSize',[H,W])    ;set(f1,'PaperPosition',[0,0,W,H]);
xlabel('$$ x $$','Interpreter','latex');
ylabel('$$ y $$','Interpreter','latex');
%title(strcat('t=',num2str(X_lft(k,2))));
legend('NE-PIELM','Exact','Location','best')
% axis([Xmin,Xmax,-0.1,1.1])
print(f1,'-depsc','fig4_2b.eps');
