function y=phi(x)
         y=tanh(x);
end  